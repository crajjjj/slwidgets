SexLab Widgets SSE
=======================

A  plugin for iWant Status Bars to add sexlab related widgets to Skyrim. Supports 2 mechanics
- Icons that have 9 stages and change dynamically
- Icons that appear/dissapear on condition
113 icons included.
MCM for flexible configuration


Supported plugins: 

Stages:
- vSLA SE (SexLab Aroused eXtended/SLAM) - Arousal and exposure icons
- vApropos2 - w&t icons
- vFill her up - cum icon
- MME - milk and lactacid
- PAF and MiniNeeds - piss and poop icons
Toggles:
- SexLab-Parasite - spider eggs, chaurus worms
- Pregnancy: HentaiPregnancy, BeeingFemale, EggFactory, EstrusChaurus, EstrusSpider, EstrusDwemer, FM3  - cum inflation/ovulation/pregnancy
- Defeat: SLDefeat -weakened (raped)




Installation

- Install as any other mod. SE version is esl based. (LE version - esp works for SE as well)

- (Optional) Flexible icon configuration via SLWidgets MCM 

- (Optional) Save SLWidget properties via MCM (autopreload for new saves - inspired by Settings Loader Series)

- (Optional) Configure icon placement/color/size in iWant Status Bars MCM. You can use multiple bars as well

- (Optional) Use custom icons packs from download section. Just install as any other mode (dds icons only)



Hard Requirements

iWant Status Bars
iWant Widgets
PapyrusUtil


Soft Dependencies

Sexlab Aroused SE (any version will do, including SLAX)
Apropos2 SE
Fill her up 
Fertility Mod 3
HentaiPregnancy
BeeingFemale
EggFactory
SexLab-Parasite
EstrusChaurus
EstrusSpider
EstrusDwemer
PAF
MiniNeeds
SLDefeat



Incompatible mods:

Affected indirectly by mods that impact iWant Widgets.  Mods significantly altering hudmenu.gfx directly or via a hudmenu.swf file may prevent image display.

Tested in different mod lists with multiple UI mods (Tsukiro/D&DDC)



Customization:

You can use your own icons. To do that put them into mod -  \Interface\exported\widgets\iwant\widgets\library\.. folders. Just follow the naming convention already in place.

Supported icon format is .dds. Image size 100x100. 

To convert you can use Gimp (pick bc3 compression/no mipmaps when exporting to dds).



Notes on LE installation

LE version of the iWant Status Bars/iWant Widgets is included in the fomod of the SE version. 

